from flask_login import UserMixin

class User(UserMixin):
    def __init__(self, id_usuario, usuario, password):
        self.id = str(id_usuario)
        self.id_usuario = id_usuario
        self.usuario = usuario
        self.password = password

    @staticmethod
    def get_by_id(conexion, user_id):
        cursor = conexion.cursor()
        cursor.execute("SELECT id_usuario, usuario, password FROM usuarios WHERE id_usuario = ?", (user_id,))
        row = cursor.fetchone()
        cursor.close()
        if row:
            return User(id_usuario=row[0], usuario=row[1], password=row[2])
        return None

    @staticmethod
    def get_by_username(conexion, username):
        cursor = conexion.cursor()
        cursor.execute("SELECT id_usuario, usuario, password FROM usuarios WHERE usuario = ?", (username,))
        row = cursor.fetchone()
        cursor.close()
        if row:
            return User(id_usuario=row[0], usuario=row[1], password=row[2])
        return None