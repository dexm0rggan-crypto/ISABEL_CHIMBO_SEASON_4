import sqlite3
import os

def obtener_conexion():
    """Establece y retorna una conexión a la base de datos SQLite local."""
    try:
        # Ruta del archivo de base de datos local
        ruta_db = 'sistema_academico.db'
        conexion = sqlite3.connect(ruta_db)
        # Esto permite acceder a las columnas por nombre (como dictionary=True en MySQL)
        conexion.row_factory = sqlite3.Row
        return conexion
    except Exception as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None