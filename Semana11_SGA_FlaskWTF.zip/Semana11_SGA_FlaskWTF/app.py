from flask import Flask, render_template, request, redirect, url_for, flash
from conexion.conexion import obtener_conexion
from forms.producto_form import ProductoForm

app = Flask(__name__)
app.secret_key = 'clave_secreta_sga'
app.config['WTF_CSRF_ENABLED'] = False

@app.route('/')
def index():
    return render_template('index.html', nombre_sistema="Sistema de Gestión Académica", resumen="Plataforma académica.")

# --- MÓDULO PRODUCTOS: LISTAR (Con JOIN a proveedores) ---
@app.route('/productos')
def listar_productos():
    conexion = obtener_conexion()
    productos = []
    if conexion:
        cursor = conexion.cursor()
        query = """
            SELECT p.id_producto, p.nombre, p.precio, p.stock, prv.nombre AS proveedor 
            FROM productos p 
            LEFT JOIN proveedores prv ON p.id_proveedor = prv.id_proveedor
        """
        cursor.execute(query)
        resultados = cursor.fetchall()
        for row in resultados:
            productos.append({
                'id_producto': row[0],
                'nombre': row[1],
                'precio': row[2],
                'stock': row[3],
                'proveedor': row[4]
            })
        cursor.close()
        conexion.close()
    return render_template('productos.html', productos=productos)

# --- MÓDULO PRODUCTOS: AGREGAR (Flask-WTF e INSERT) ---
@app.route('/productos/agregar', methods=['GET', 'POST'])
def agregar_producto():
    form = ProductoForm()
    if form.validate_on_submit():
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                query = "INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)"
                precio_val = float(form.precio.data) if form.precio.data is not None else 0.0
                stock_val = int(form.stock.data) if form.stock.data is not None else 0
                
                cursor.execute(query, (form.nombre.data, precio_val, stock_val))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Producto agregado exitosamente', 'success')
                return redirect(url_for('listar_productos'))
            except Exception as e:
                print(f"Error en base de datos: {e}")
                flash(f"Error al guardar en BD: {e}", "danger")
    else:
        if request.method == 'POST':
            print("Errores de validación WTF:", form.errors)
    return render_template('formulario_prod.html', form=form, legend="Nuevo Producto")

# --- MÓDULO PRODUCTOS: MODIFICAR (UPDATE con WHERE) ---
@app.route('/productos/editar/<int:id>', methods=['GET', 'POST'])
def editar_producto(id):
    conexion = obtener_conexion()
    form = ProductoForm()
    
    if request.method == 'POST':
        if form.validate_on_submit():
            if conexion:
                cursor = conexion.cursor()
                query = "UPDATE productos SET nombre = ?, precio = ?, stock = ? WHERE id_producto = ?"
                precio_val = float(form.precio.data) if form.precio.data is not None else 0.0
                stock_val = int(form.stock.data) if form.stock.data is not None else 0
                
                cursor.execute(query, (form.nombre.data, precio_val, stock_val, id))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Producto modificado exitosamente', 'success')
                return redirect(url_for('listar_productos'))
    else:
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT nombre, precio, stock FROM productos WHERE id_producto = ?", (id,))
            row = cursor.fetchone()
            cursor.close()
            conexion.close()
            
            if row:
                # Precargamos los datos directamente en los campos del formulario
                form.nombre.data = row[0]
                form.precio.data = row[1]
                form.stock.data = row[2]
                
    return render_template('formulario_prod.html', form=form, legend="Editar Producto")

# --- MÓDULO PRODUCTOS: ELIMINAR (DELETE con WHERE) ---
@app.route('/productos/eliminar/<int:id>', methods=['POST'])
def eliminar_producto(id):
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        query = "DELETE FROM productos WHERE id_producto = ?"
        cursor.execute(query, (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        flash('Producto eliminado correctamente', 'danger')
    return redirect(url_for('listar_productos'))

# Rutas adicionales
@app.route('/clientes')
def clientes():
    return render_template('clientes.html')

@app.route('/proveedores')
def proveedores():
    return render_template('proveedores.html')

@app.route('/facturacion')
def facturacion():
    return render_template('facturacion.html')

if __name__ == '__main__':
    app.run(debug=True)