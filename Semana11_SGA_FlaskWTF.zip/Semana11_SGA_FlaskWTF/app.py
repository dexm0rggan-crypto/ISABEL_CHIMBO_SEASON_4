from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from conexion.conexion import obtener_conexion
try:
    from models import User
except ImportError:
    from conexion.models import User

from forms.login_form import LoginForm
from forms.usuario_form import RegistroForm
from forms.producto_form import ProductoForm

app = Flask(__name__)
app.secret_key = 'clave_secreta_sga'
app.config['WTF_CSRF_ENABLED'] = False

# --- CONFIGURACIÓN DE FLASK-LOGIN ---
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, inicia sesión para acceder a esta página.'
login_manager.login_message_category = 'warning'

@login_manager.user_loader
def load_user(user_id):
    conexion = obtener_conexion()
    if conexion:
        user = User.get_by_id(conexion, user_id)
        conexion.close()
        return user
    return None


# --- CREACIÓN AUTOMÁTICA DE TABLAS EN LA BD ---
def inicializar_bd():
    conexion = obtener_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                    usuario TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS proveedores (
                    id_proveedor INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    telefono TEXT,
                    email TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS clientes (
                    id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    cedula TEXT,
                    telefono TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS productos (
                    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    precio REAL NOT NULL,
                    stock INTEGER NOT NULL,
                    id_proveedor INTEGER,
                    FOREIGN KEY (id_proveedor) REFERENCES proveedores(id_proveedor)
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS facturas (
                    id_factura INTEGER PRIMARY KEY AUTOINCREMENT,
                    numero_factura TEXT NOT NULL,
                    cliente TEXT NOT NULL,
                    total REAL NOT NULL
                )
            """)
            conexion.commit()
            cursor.close()
        except Exception as e:
            print(f"Error al inicializar las tablas: {e}")
        finally:
            conexion.close()


@app.route('/')
def index():
    return render_template('index.html', nombre_sistema="Sistema de Gestión", resumen="Plataforma de gestión comercial.")


# --- RUTAS DE AUTENTICACIÓN ---

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    form = RegistroForm()
    if form.validate_on_submit():
        usuario = form.usuario.data
        password_hash = generate_password_hash(form.password.data)
        
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO usuarios (usuario, password) VALUES (?, ?)", (usuario, password_hash))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('¡Registro exitoso! Ahora puedes iniciar sesión.', 'success')
                return redirect(url_for('login'))
            except Exception as e:
                conexion.rollback()
                flash(f'El nombre de usuario ya existe o ocurrió un error: {e}', 'danger')
    return render_template('registro.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    form = LoginForm()
    if form.validate_on_submit():
        conexion = obtener_conexion()
        if conexion:
            user = User.get_by_username(conexion, form.usuario.data)
            conexion.close()
            
            if user and check_password_hash(user.password, form.password.data):
                login_user(user)
                flash(f'Bienvenido, {user.usuario}', 'success')
                next_page = request.args.get('next')
                return redirect(next_page or url_for('dashboard'))
            else:
                flash('Usuario o contraseña incorrectos.', 'danger')
                
    return render_template('login.html', form=form)


@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado sesión correctamente.', 'info')
    return redirect(url_for('login'))


# --- MÓDULO PRODUCTOS ---
@app.route('/productos')
@login_required
def listar_productos():
    conexion = obtener_conexion()
    productos = []
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("SELECT id_producto, nombre, precio, stock FROM productos")
        for row in cursor.fetchall():
            productos.append({'id_producto': row[0], 'nombre': row[1], 'precio': row[2], 'stock': row[3]})
        cursor.close()
        conexion.close()
    return render_template('productos.html', productos=productos)

@app.route('/productos/agregar', methods=['GET', 'POST'])
@login_required
def agregar_producto():
    form = ProductoForm()
    if form.validate_on_submit():
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)", 
                               (form.nombre.data, float(form.precio.data or 0.0), int(form.stock.data or 0)))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Producto agregado exitosamente', 'success')
                return redirect(url_for('listar_productos'))
            except Exception as e:
                flash(f"Error al guardar producto: {e}", "danger")
    return render_template('formulario_prod.html', form=form, legend="Nuevo Producto")

@app.route('/productos/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_producto(id):
    conexion = obtener_conexion()
    form = ProductoForm()
    
    if request.method == 'POST':
        if form.validate_on_submit():
            if conexion:
                cursor = conexion.cursor()
                cursor.execute("UPDATE productos SET nombre = ?, precio = ?, stock = ? WHERE id_producto = ?",
                               (form.nombre.data, float(form.precio.data or 0.0), int(form.stock.data or 0), id))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Producto modificado exitosamente', 'success')
                return redirect(url_for('listar_productos'))
    else:
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT nombre, precio, stock FROM productos WHERE id_producto = ?", (id,))
            row = cursor.fetchone()
            cursor.close()
            conexion.close()
            if row:
                form.nombre.data = row[0]
                form.precio.data = row[1]
                form.stock.data = row[2]
                
    return render_template('formulario_prod.html', form=form, legend="Editar Producto")

@app.route('/productos/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_producto(id):
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM productos WHERE id_producto = ?", (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        flash('Producto eliminado correctamente', 'danger')
    return redirect(url_for('listar_productos'))


# --- MÓDULO CLIENTES ---
@app.route('/clientes')
@login_required
def clientes():
    conexion = obtener_conexion()
    lista_clientes = []
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("SELECT id_cliente, nombre, cedula, telefono FROM clientes")
        for row in cursor.fetchall():
            lista_clientes.append({'id_cliente': row[0], 'nombre': row[1], 'cedula': row[2], 'telefono': row[3]})
        cursor.close()
        conexion.close()
    return render_template('clientes.html', clientes=lista_clientes)

@app.route('/clientes/agregar', methods=['GET', 'POST'])
@login_required
def formulario_cliente():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        cedula = request.form.get('cedula')
        telefono = request.form.get('telefono')
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO clientes (nombre, cedula, telefono) VALUES (?, ?, ?)", (nombre, cedula, telefono))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Cliente registrado exitosamente', 'success')
                return redirect(url_for('clientes'))
            except Exception as e:
                flash(f'Error al registrar cliente: {e}', 'danger')
    return render_template('formulario_cliente.html', legend="Nuevo Cliente", cliente=None)

@app.route('/clientes/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_cliente(id):
    conexion = obtener_conexion()
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        cedula = request.form.get('cedula')
        telefono = request.form.get('telefono')
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("UPDATE clientes SET nombre = ?, cedula = ?, telefono = ? WHERE id_cliente = ?", (nombre, cedula, telefono, id))
            conexion.commit()
            cursor.close()
            conexion.close()
            flash('Cliente modificado con éxito', 'success')
            return redirect(url_for('clientes'))
    else:
        cliente = None
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT id_cliente, nombre, cedula, telefono FROM clientes WHERE id_cliente = ?", (id,))
            row = cursor.fetchone()
            if row:
                cliente = {'id_cliente': row[0], 'nombre': row[1], 'cedula': row[2], 'telefono': row[3]}
            cursor.close()
            conexion.close()
        return render_template('formulario_cliente.html', legend="Editar Cliente", cliente=cliente)

@app.route('/clientes/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_cliente(id):
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM clientes WHERE id_cliente = ?", (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        flash('Cliente eliminado correctamente', 'danger')
    return redirect(url_for('clientes'))


# --- MÓDULO PROVEEDORES ---
@app.route('/proveedores')
@login_required
def proveedores():
    conexion = obtener_conexion()
    lista_proveedores = []
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("SELECT id_proveedor, nombre, telefono, email FROM proveedores")
        for row in cursor.fetchall():
            lista_proveedores.append({'id_proveedor': row[0], 'nombre': row[1], 'telefono': row[2], 'email': row[3]})
        cursor.close()
        conexion.close()
    return render_template('proveedores.html', proveedores=lista_proveedores)

@app.route('/proveedores/agregar', methods=['GET', 'POST'])
@login_required
def formulario_proveedor():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        telefono = request.form.get('telefono')
        email = request.form.get('email')
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO proveedores (nombre, telefono, email) VALUES (?, ?, ?)", (nombre, telefono, email))
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Proveedor registrado exitosamente', 'success')
                return redirect(url_for('proveedores'))
            except Exception as e:
                flash(f'Error al registrar proveedor: {e}', 'danger')
    return render_template('formulario_proveedor.html', legend="Nuevo Proveedor", proveedor=None)

@app.route('/proveedores/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_proveedor(id):
    conexion = obtener_conexion()
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        telefono = request.form.get('telefono')
        email = request.form.get('email')
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("UPDATE proveedores SET nombre = ?, telefono = ?, email = ? WHERE id_proveedor = ?", (nombre, telefono, email, id))
            conexion.commit()
            cursor.close()
            conexion.close()
            flash('Proveedor modificado con éxito', 'success')
            return redirect(url_for('proveedores'))
    else:
        proveedor = None
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT id_proveedor, nombre, telefono, email FROM proveedores WHERE id_proveedor = ?", (id,))
            row = cursor.fetchone()
            if row:
                proveedor = {'id_proveedor': row[0], 'nombre': row[1], 'telefono': row[2], 'email': row[3]}
            cursor.close()
            conexion.close()
        return render_template('formulario_proveedor.html', legend="Editar Proveedor", proveedor=proveedor)

@app.route('/proveedores/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_proveedor(id):
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM proveedores WHERE id_proveedor = ?", (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        flash('Proveedor eliminado correctamente', 'danger')
    return redirect(url_for('proveedores'))


# --- MÓDULO FACTURACIÓN ---
@app.route('/facturacion')
@login_required
def facturacion():
    conexion = obtener_conexion()
    lista_facturas = []
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("SELECT id_factura, numero_factura, cliente, total FROM facturas")
        for row in cursor.fetchall():
            lista_facturas.append({
                'id_factura': row[0],
                'numero_factura': row[1],
                'cliente': row[2],
                'total': row[3]
            })
        cursor.close()
        conexion.close()
    return render_template('facturacion.html', facturas=lista_facturas)

@app.route('/facturacion/nuevo', methods=['GET', 'POST'])
@login_required
def formulario_facturacion():
    if request.method == 'POST':
        numero_factura = request.form.get('numero_factura')
        cliente = request.form.get('cliente')
        total = request.form.get('total')
        conexion = obtener_conexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO facturas (numero_factura, cliente, total) VALUES (?, ?, ?)", 
                    (numero_factura, cliente, float(total or 0.0))
                )
                conexion.commit()
                cursor.close()
                conexion.close()
                flash('Factura guardada y emitida exitosamente', 'success')
                return redirect(url_for('facturacion'))
            except Exception as e:
                flash(f'Error al guardar factura: {e}', 'danger')
    return render_template('formulario_facturacion.html', factura=None)

@app.route('/facturacion/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_factura(id):
    conexion = obtener_conexion()
    if request.method == 'POST':
        numero_factura = request.form.get('numero_factura')
        cliente = request.form.get('cliente')
        total = request.form.get('total')
        if conexion:
            cursor = conexion.cursor()
            cursor.execute(
                "UPDATE facturas SET numero_factura = ?, cliente = ?, total = ? WHERE id_factura = ?",
                (numero_factura, cliente, float(total or 0.0), id)
            )
            conexion.commit()
            cursor.close()
            conexion.close()
            flash('Factura modificada con éxito', 'success')
            return redirect(url_for('facturacion'))
    else:
        factura = None
        if conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT id_factura, numero_factura, cliente, total FROM facturas WHERE id_factura = ?", (id,))
            row = cursor.fetchone()
            if row:
                factura = {
                    'id_factura': row[0],
                    'numero_factura': row[1],
                    'cliente': row[2],
                    'total': row[3]
                }
            cursor.close()
            conexion.close()
        return render_template('formulario_facturacion.html', factura=factura)

@app.route('/facturacion/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_factura(id):
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM facturas WHERE id_factura = ?", (id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        flash('Factura eliminada correctamente', 'danger')
    return redirect(url_for('facturacion'))


if __name__ == '__main__':
    inicializar_bd()
    app.run(debug=True)