// Funcionalidad del formulario de solicitudes de la página de inicio.
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formSolicitud");
    const lista = document.getElementById("lista");
    const contador = document.getElementById("contador");
    const mensaje = document.getElementById("mensaje");
    const spinner = document.getElementById("spinnerCarga");
    const detalleModalElement = document.getElementById("modalDetalle");
    const eliminarModalElement = document.getElementById("modalEliminar");

    if (!form || !lista || !contador) {
        return;
    }

    const detalleModal = detalleModalElement ? new bootstrap.Modal(detalleModalElement) : null;
    const modalEliminar = eliminarModalElement ? new bootstrap.Modal(eliminarModalElement) : null;
    const detalleContenido = document.getElementById("detalleModal");
    const btnEliminar = document.getElementById("btnEliminar");

    let registros = JSON.parse(localStorage.getItem("registros")) || [];
    let indiceEliminar = null;

    function guardarDatos() {
        localStorage.setItem("registros", JSON.stringify(registros));
    }

    function mostrarMensaje(texto, tipo) {
        if (!mensaje) return;
        mensaje.className = `alert alert-${tipo}`;
        mensaje.textContent = texto;
        mensaje.classList.remove("d-none");
        setTimeout(() => mensaje.classList.add("d-none"), 3000);
    }

    function actualizarContador() {
        contador.textContent = registros.length;
    }

    function renderizarRegistros() {
        lista.innerHTML = "";

        if (registros.length === 0) {
            lista.innerHTML = '<div class="col-12"><div class="alert alert-secondary text-center">No existen solicitudes registradas.</div></div>';
        }

        registros.forEach((item, index) => {
            lista.innerHTML += `
                <div class="col-md-4 mb-4">
                    <div class="card shadow h-100 border-0">
                        <div class="card-body">
                            <h5 class="card-title text-primary">
                                <i class="bi bi-person-fill"></i> ${item.nombre}
                            </h5>
                            <h6 class="text-secondary mb-3">${item.tipo}</h6>
                            <p class="card-text">${item.descripcion}</p>
                        </div>
                        <div class="card-footer bg-white border-0">
                            ${detalleModal ? `<button class="btn btn-primary btn-sm me-2" onclick="verDetalle(${index})"><i class="bi bi-eye-fill"></i> Ver</button>` : ""}
                            ${modalEliminar ? `<button class="btn btn-danger btn-sm" onclick="confirmarEliminar(${index})"><i class="bi bi-trash-fill"></i> Eliminar</button>` : ""}
                        </div>
                    </div>
                </div>`;
        });

        actualizarContador();
        guardarDatos();
    }

    window.verDetalle = function(index) {
        if (!detalleModal || !detalleContenido) return;
        const registro = registros[index];
        detalleContenido.innerHTML = `
            <strong>Nombre:</strong> ${registro.nombre}<br><br>
            <strong>Tipo:</strong> ${registro.tipo}<br><br>
            <strong>Descripción:</strong><br>${registro.descripcion}`;
        detalleModal.show();
    };

    window.confirmarEliminar = function(index) {
        if (!modalEliminar) return;
        indiceEliminar = index;
        modalEliminar.show();
    };

    if (btnEliminar && modalEliminar) {
        btnEliminar.addEventListener("click", () => {
            if (indiceEliminar !== null) {
                registros.splice(indiceEliminar, 1);
                renderizarRegistros();
                mostrarMensaje("La solicitud fue eliminada correctamente.", "danger");
                indiceEliminar = null;
                modalEliminar.hide();
            }
        });
    }

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const nombre = document.getElementById("nombre").value.trim();
        const descripcion = document.getElementById("descripcion").value.trim();
        const tipo = document.getElementById("tipo").value;

        if (nombre.length < 3 || descripcion.length < 10 || tipo === "") {
            form.classList.add("was-validated");
            mostrarMensaje("Complete correctamente todos los campos.", "warning");
            return;
        }

        if (spinner) spinner.classList.remove("d-none");

        setTimeout(() => {
            if (spinner) spinner.classList.add("d-none");
            registros.push({ nombre, descripcion, tipo });
            renderizarRegistros();
            mostrarMensaje("Solicitud registrada correctamente.", "success");
            form.reset();
            form.classList.remove("was-validated");
        }, 700);
    });

    renderizarRegistros();
});
