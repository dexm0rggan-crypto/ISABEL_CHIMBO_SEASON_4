from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, DecimalField, SubmitField
from wtforms.validators import DataRequired, Length, NumberRange

class ProductoForm(FlaskForm):
    nombre = StringField(
        "Nombre",
        validators=[DataRequired(message="El nombre es obligatorio."), Length(min=3, max=100, message="Debe tener entre 3 y 100 caracteres.")]
    )
    descripcion = TextAreaField(
        "Descripción",
        validators=[DataRequired(message="La descripción es obligatoria."), Length(min=10, max=250, message="Debe tener entre 10 y 250 caracteres.")]
    )
    tipo = SelectField(
        "Tipo",
        choices=[("", "Seleccione una opción"), ("Proceso", "Proceso"), ("Servicio", "Servicio"), ("Consulta", "Consulta")],
        validators=[DataRequired(message="Seleccione el tipo.")]
    )
    estado = SelectField(
        "Estado",
        choices=[("", "Seleccione una opción"), ("Disponible", "Disponible"), ("Agotado", "Agotado")],
        validators=[DataRequired(message="Seleccione el estado.")]
    )
    precio = DecimalField(
        "Valor referencial ($)",
        places=2,
        validators=[DataRequired(message="El valor es obligatorio."), NumberRange(min=0, max=100000, message="Ingrese un valor entre 0 y 100000.")]
    )
    submit = SubmitField("Guardar producto")
