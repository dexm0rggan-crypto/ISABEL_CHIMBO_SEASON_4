from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length

class ProveedorForm(FlaskForm):
    nombre = StringField(
        "Nombre del proveedor",
        validators=[DataRequired(message="El nombre es obligatorio."), Length(min=3, max=100, message="Debe tener entre 3 y 100 caracteres.")]
    )
    descripcion = TextAreaField(
        "Descripción",
        validators=[DataRequired(message="La descripción es obligatoria."), Length(min=10, max=250, message="Debe tener entre 10 y 250 caracteres.")]
    )
    estado = SelectField(
        "Estado",
        choices=[("", "Seleccione una opción"), ("Activo", "Activo"), ("Disponible", "Disponible")],
        validators=[DataRequired(message="Seleccione el estado.")]
    )
    submit = SubmitField("Guardar proveedor")
