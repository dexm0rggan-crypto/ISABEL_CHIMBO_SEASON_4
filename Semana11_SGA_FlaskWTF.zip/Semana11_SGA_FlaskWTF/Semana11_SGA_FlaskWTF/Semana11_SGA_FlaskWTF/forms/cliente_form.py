from flask_wtf import FlaskForm
from wtforms import StringField, EmailField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, Email

class ClienteForm(FlaskForm):
    identificacion = StringField(
        "Identificación",
        validators=[DataRequired(message="La identificación es obligatoria."), Length(min=3, max=20, message="Debe tener entre 3 y 20 caracteres.")]
    )
    nombre = StringField(
        "Nombre completo",
        validators=[DataRequired(message="El nombre es obligatorio."), Length(min=3, max=100, message="Debe tener entre 3 y 100 caracteres.")]
    )
    correo = EmailField(
        "Correo electrónico",
        validators=[DataRequired(message="El correo es obligatorio."), Email(message="Ingrese un correo electrónico válido.")]
    )
    estado = SelectField(
        "Estado",
        choices=[("", "Seleccione una opción"), ("Activo", "Activo"), ("Pendiente", "Pendiente")],
        validators=[DataRequired(message="Seleccione el estado.")]
    )
    submit = SubmitField("Guardar cliente")
