from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DateField, DecimalField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, NumberRange

class FacturacionForm(FlaskForm):
    numero = StringField(
        "Número de factura",
        validators=[DataRequired(message="El número de factura es obligatorio."), Length(min=4, max=20, message="Debe tener entre 4 y 20 caracteres.")]
    )
    concepto = TextAreaField(
        "Concepto",
        validators=[DataRequired(message="El concepto es obligatorio."), Length(min=3, max=150, message="Debe tener entre 3 y 150 caracteres.")]
    )
    fecha = DateField(
        "Fecha",
        format="%Y-%m-%d",
        validators=[DataRequired(message="La fecha es obligatoria.")]
    )
    valor = DecimalField(
        "Valor ($)",
        places=2,
        validators=[DataRequired(message="El valor es obligatorio."), NumberRange(min=0.01, max=100000, message="Ingrese un valor mayor a 0 y hasta 100000.")]
    )
    estado = SelectField(
        "Estado",
        choices=[("", "Seleccione una opción"), ("Pagada", "Pagada"), ("Pendiente", "Pendiente")],
        validators=[DataRequired(message="Seleccione el estado.")]
    )
    submit = SubmitField("Guardar factura")
