import sqlite3
from flask import Flask, render_template, request, redirect, url_for
from forms.producto_form import ProductoForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'clave-secreta-para-wtforms'

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return "Bienvenido al sistema académico y de productos"

@app.route('/productos')
def productos():
    conn = get_db_connection()
    productos = conn.execute('SELECT * FROM productos').fetchall()
    conn.close()
    return render_template('productos.html', productos=productos)

@app.route('/productos/crear', methods=('GET', 'POST'))
def crear_producto():
    form = ProductoForm()
    if form.validate_on_submit():
        nombre = form.nombre.data
        descripcion = form.descripcion.data
        tipo = form.tipo.data
        estado = form.estado.data
        precio = float(form.precio.data)  # Convertimos el decimal a float para SQLite

        conn = get_db_connection()
        conn.execute('INSERT INTO productos (nombre, descripcion, tipo, estado, valor) VALUES (?, ?, ?, ?, ?)',
                     (nombre, descripcion, tipo, estado, precio))
        conn.commit()
        conn.close()
        
        return redirect(url_for('productos'))
        
    return render_template('formulario_prod.html', form=form)

@app.route('/clientes')
def clientes():
    return "Sección de Clientes"

@app.route('/facturacion')
def facturacion():
    return "Sección de Facturación"

@app.route('/proveedores')
def proveedores():
    return "Sección de Proveedores"

if __name__ == '__main__':
    app.run(debug=True)