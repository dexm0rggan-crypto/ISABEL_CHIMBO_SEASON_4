# Sistema de Gestión Académica - Semana 11

Proyecto Integrador de Desarrollo de Aplicaciones Web. Este avance continúa el proyecto de la Semana 10 e incorpora formularios con Flask-WTF y WTForms.

## Requisitos
- Python 3.10 o superior recomendado
- Flask
- Flask-WTF
- WTForms
- email-validator

## Instalación

1. Crear y activar el entorno virtual:

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

2. Instalar dependencias:

```bash
pip install -r requirements.txt
```

Si se desea instalar directamente la dependencia nueva indicada en la tarea:
```bash
pip install flask-wtf
```

3. Ejecutar:

```bash
python app.py
```

Abrir: http://127.0.0.1:5000

## Formularios implementados

- `/productos/nuevo` - ProductoForm
- `/clientes/nuevo` - ClienteForm
- `/proveedores/nuevo` - ProveedorForm
- `/facturacion/nuevo` - FacturacionForm

Todos aceptan GET y POST, utilizan `validate_on_submit()`, `hidden_tag()` para CSRF y mensajes de validación debajo de cada campo.

## Persistencia

Esta semana no se utiliza base de datos. Los registros enviados correctamente se agregan temporalmente a listas Python y se pierden al reiniciar la aplicación.

## GitHub

```bash
git add .
git commit -m "Semana 11: formularios Flask-WTF y validaciones"
git push origin main
```
