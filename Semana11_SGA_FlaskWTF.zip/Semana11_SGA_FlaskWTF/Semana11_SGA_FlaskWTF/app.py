from flask import Flask, render_template, request, redirect, url_for, flash
from forms.producto_form import ProductoForm
from forms.cliente_form import ClienteForm
from forms.proveedor_form import ProveedorForm
from forms.facturacion_form import FacturacionForm
import sqlite3

app = Flask(__name__)
app.config["SECRET_KEY"] = "SGA-Semana11-2026-ClaveSegura"

# --- FUNCIÓN DE CONEXIÓN A SQLITE ---
def get_db_connection():
    conn = sqlite3.connect('sistema_academico.db')
    conn.row_factory = sqlite3.Row
    return conn

# --- INICIALIZAR TABLA DE PRODUCTOS EN LA BD ---
def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT NOT NULL,
            precio REAL NOT NULL,
            stock INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

nombre_sistema = "Sistema de Gestión Académica"

resumen = {
    "estudiantes": 125,
    "docentes": 18,
    "materias": 32,
    "solicitudes": 8
}

@app.route('/')
def index():
    return render_template('index.html', nombre_sistema=nombre_sistema, resumen=resumen)


# --- 4. SELECT y 5. Jinja2: Mostrar productos desde SQLite en la tabla HTML ---
@app.route('/productos')
def listar_productos():
    conn = get_db_connection()
    # SELECT para extraer todos los productos guardados
    productos = conn.execute('SELECT * FROM productos').fetchall()
    conn.close()
    return render_template('productos.html', productos=productos)


# --- 1. Formulario, 2. Validación, 3. INSERT en SQLite ---
@app.route('/productos/crear', methods=('GET', 'POST'))
def crear_producto():
    form = ProductoForm()
    if request.method == 'POST':
        # 2. Validación mediante Flask-WTF
        if form.validate_on_submit():
            nombre = form.nombre.data
            descripcion = form.descripcion.data
            precio = form.precio.data
            stock = form.stock.data

            # 3. INSERT en la base de datos SQLite
            conn = get_db_connection()
            conn.execute(
                'INSERT INTO productos (nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)',
                (nombre, descripcion, precio, stock)
            )
            conn.commit()
            conn.close()

            flash('¡Producto registrado y guardado con éxito en la base de datos!', 'success')
            return redirect(url_for('listar_productos'))
            
    return render_template('formulario_prod.html', form=form)


# (El resto de tus rutas de clientes, proveedores, facturación déjalas abajo tal como las tengas)

if __name__ == '__main__':
    app.run(debug=True)