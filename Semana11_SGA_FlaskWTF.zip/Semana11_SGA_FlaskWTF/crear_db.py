from conexion.conexion import obtener_conexion

def ejecutar_esquema():
    conexion = obtener_conexion()
    if conexion:
        cursor = conexion.cursor()
        with open('sql/esquema.sql', 'r', encoding='utf-8') as f:
            script = f.read()
        
        # Ejecutar cada sentencia separada por punto y coma
        for sentencia in script.split(';'):
            if sentencia.strip():
                cursor.execute(sentencia)
        
        conexion.commit()
        cursor.close()
        conexion.close()
        print("¡Base de datos y tablas creadas exitosamente desde el esquema.sql!")
    else:
        print("No se pudo conectar a la base de datos.")

if __name__ == '__main__':
    ejecutar_esquema()