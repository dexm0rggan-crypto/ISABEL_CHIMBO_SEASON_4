from flask import Flask, render_template

app = Flask(__name__)

# Datos de ejemplo del sistema (Semana 10 - Jinja2)
nombre_sistema = "Sistema de Gestión Académica"

resumen = {
    "estudiantes": 125,
    "docentes": 18,
    "materias": 32,
    "solicitudes": 8
}

productos_data = [
    {"nombre": "Matrícula", "descripcion": "Gestión de procesos de matrícula académica.", "estado": "Disponible", "tipo": "Proceso"},
    {"nombre": "Certificados", "descripcion": "Solicitud y administración de certificados académicos.", "estado": "Disponible", "tipo": "Servicio"},
    {"nombre": "Reportes", "descripcion": "Generación de reportes relacionados con la información académica.", "estado": "Disponible", "tipo": "Servicio"},
    {"nombre": "Historial académico", "descripcion": "Consulta organizada del historial académico del estudiante.", "estado": "Agotado", "tipo": "Consulta"},
]

clientes_data = [
    {"id": "001", "nombre": "María González", "correo": "maria@example.com", "estado": "Activo"},
    {"id": "002", "nombre": "Juan Pérez", "correo": "juan@example.com", "estado": "Activo"},
    {"id": "003", "nombre": "Andrea López", "correo": "andrea@example.com", "estado": "Pendiente"},
    {"id": "004", "nombre": "Carlos Torres", "correo": "carlos@example.com", "estado": "Activo"},
]

proveedores_data = [
    {"nombre": "Proveedor Tecnológico", "descripcion": "Servicios y recursos tecnológicos.", "estado": "Activo", "icono": "bi-building"},
    {"nombre": "Proveedor Académico", "descripcion": "Materiales y recursos educativos.", "estado": "Activo", "icono": "bi-book"},
    {"nombre": "Servicios Informáticos", "descripcion": "Soporte y mantenimiento informático.", "estado": "Disponible", "icono": "bi-laptop"},
]

facturas_data = [
    {"numero": "FAC-001", "concepto": "Matrícula", "fecha": "10/08/2026", "valor": 150.00, "estado": "Pagada"},
    {"numero": "FAC-002", "concepto": "Certificado académico", "fecha": "12/08/2026", "valor": 25.00, "estado": "Pendiente"},
    {"numero": "FAC-003", "concepto": "Solicitud académica", "fecha": "14/08/2026", "valor": 10.00, "estado": "Pagada"},
    {"numero": "FAC-004", "concepto": "Historial académico", "fecha": "16/08/2026", "valor": 15.00, "estado": "Pendiente"},
]


@app.route("/")
def index():
    return render_template(
        "index.html",
        nombre_sistema=nombre_sistema,
        resumen=resumen
    )


@app.route("/productos")
def productos():
    return render_template(
        "productos.html",
        productos=productos_data,
        nombre_sistema=nombre_sistema
    )


@app.route("/clientes")
def clientes():
    return render_template(
        "clientes.html",
        clientes=clientes_data,
        nombre_sistema=nombre_sistema
    )


@app.route("/proveedores")
def proveedores():
    return render_template(
        "proveedores.html",
        proveedores=proveedores_data,
        nombre_sistema=nombre_sistema
    )


@app.route("/facturacion")
def facturacion():
    return render_template(
        "facturacion.html",
        facturas=facturas_data,
        nombre_sistema=nombre_sistema
    )


if __name__ == "__main__":
    app.run(debug=True)
